Fire Services Central Ltd — unofficial personalised demo
Batch: 2026-08-06-batch-17

Open index.html locally or deploy this folder as a standalone static website.
No build step is required. The form is simulated and sends no data.

Verified public contact:
Email: info@fire.uk.net
Phone: 0121 525 1976
Official site: https://www.fire.uk.net/

Deployment status: LINK_PENDING. Do not place a URL in outreach until the exact public URL is tested signed out over HTTPS.
